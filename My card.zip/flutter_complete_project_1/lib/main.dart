import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Scaffold(
      backgroundColor: Color.fromARGB(255, 2, 139, 152),
      body: Container(
        padding: EdgeInsets.fromLTRB(30, 100, 30, 0),
        child: Column(
          children: [
            CircleAvatar(
              radius: 50,
              backgroundImage: AssetImage('images/image.png.jpg'),
              
            ),
            SizedBox(
              height: 25,
            ),
           // Divider(
           //   height: 60,

          //  ),
            Text('Angel Yu',
        textAlign: TextAlign.center,
          style: TextStyle(
          fontFamily: 'ourfont',
            color:Colors.white,
            fontSize:40.5 ,
            fontWeight:FontWeight.bold,
           fontStyle: FontStyle.italic,
           
           
          ),
          ),
           Text('FLUTTER DEVELOPER',
          style: TextStyle(
          
            color:Color.fromARGB(255, 10, 215, 208),
            fontSize:20.5 ,
            fontWeight:FontWeight.bold,
           fontStyle: FontStyle.italic,
           
          )
          ),
          Column(
            children: [
              Container(
                  height:65,
                  width: double.infinity,
                  padding:EdgeInsets.all(20.5),
                  margin:EdgeInsets.fromLTRB(20,1,20,10 ),
                  color: Colors.white,
                  child:Column(
                    mainAxisAlignment:MainAxisAlignment.center,
                    children: [
                    //  Text('one'),
                       Row(
                       // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children:
                       [
                        Icon(Icons.phone),
                        SizedBox(
                          width: 60),
                        Text(' +44 123 456 789'),
                       ],)
                    
                    ],
                  ),
                 
             
             
                 ),
                 Container(
                  height:65,
                  width: double.infinity,
                  padding:EdgeInsets.all(20.5),
                  margin:EdgeInsets.fromLTRB(20,5 ,20,1),
                  color: Colors.white,
                  child:Column(
                    mainAxisAlignment:MainAxisAlignment.center,
                    children: [
                     // Text('CSE PUST'),
                       Row(
                       // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children:
                       [
                        Icon(Icons.message),
                        SizedBox(
                          width: 60),
                        Text('angela@email.com'),
                       ],)
                    
                    ],
                  ),
                  
                 ),
            ],
          )
          ],
        ),
      ),
    ),
  ));
}


