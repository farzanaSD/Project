package com.example.flutter_complete_project_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
