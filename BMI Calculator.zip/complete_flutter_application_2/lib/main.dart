import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Scaffold(
     body: TextInput(),
      ),
    ),
  );
}

class TextInput extends StatefulWidget {
  const TextInput({super.key});

  @override
  State<TextInput> createState() => _TextInputState();
}

class _TextInputState extends State<TextInput> {
  final _hightControler = TextEditingController();
  final _weightControler = TextEditingController();
  String str = 'Your Result : ';
  @override
  Widget build(BuildContext context) {
    return Container(
      
      
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('images/backimage.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        // width: double.infinity,
        child: Padding(
    // replace 16 with your desire padding value
    // padding: const EdgeInsets.all(16.0),
    padding:
        EdgeInsets.only(left: 20, top: 16, right: 20, bottom: 16),
        child: Column(
          children: [
             SizedBox(
              height: 250,
            ),
            Column(
              children: [
                Column(
                  children: [
                
                bc('BMI CALCULATOR'),
                    Row(children:[
                
                    abc('Your Weight in kg'),
                    ],
                    ),
                
                    TextField(
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            width: 5,
                            color:Color.fromARGB(255, 213, 1, 125),
                          ),
                        ),
                      ),
                      controller: _hightControler,
                    ),
                  ],
                ),
              ],
            ),
            //SizedBox(
            //  height: 30,
            // ),
            Column(
              children: [
                Row(children:[
                  SizedBox(
                  // height: 15,
                  width: 10,
                ),
                abc('Your Height in cm'),
                ],
                ),
                
                TextField(
                  
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        width: 5,
                        color:Color.fromARGB(255, 213, 1, 125),
                      ),
                    ),
                  ),
                  controller: _weightControler,
                  
                ),
              ],
            ),
            SizedBox(
              height: 50,
            ),
            Column(
              children: [
                ElevatedButton(
                    onPressed: () {
                      setState(() {
                        int w = int.parse(_hightControler.text);
                        int h = int.parse(_weightControler.text);
                        str = 'Your Result: ${(w/(h*h))}';
                      });
                    },
                    
                    child: Padding(
                      padding: EdgeInsets.only(left: 90, top: 10, right: 100, bottom: 10),
                      
                      child: Text(
                        'Calculate',
                        
                        style:
                         TextStyle(
                            color: Color.fromARGB(255, 213, 1, 125),
                            fontSize: 35),
                      ),
                      
                    )
                    )
              ],
            ),

             
            Column(
              children: [
                
              ],
            ),
            Text(
              '$str',
              style: TextStyle(fontSize: 50),
            ),
          ],
        ),
    ),);
  }
}

abc(String x) {
  return Column(children: [
    Text(
      x,
      style: TextStyle(fontSize: 20),
    )
  ]);
}

bc(String x) {
  return Column(children: [
    Text(
      x,
      style: TextStyle(color: Color.fromARGB(255, 213, 1, 125),
        fontWeight: FontWeight.bold,fontSize: 40),
    )
  ]);
}
 